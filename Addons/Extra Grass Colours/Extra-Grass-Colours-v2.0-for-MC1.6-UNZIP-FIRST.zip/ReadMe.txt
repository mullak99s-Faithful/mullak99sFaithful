~~~~~ mullak99 ~~~~~

Choose which grass variant you want (or choose both) and drag them into your resourcepack folder, place your chosen grass colour at the top of the active pack list.
 
